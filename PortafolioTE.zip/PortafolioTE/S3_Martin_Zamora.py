def calcular_ventas():
    total_venta = 0
    
    print("--- Sistema de Ventas Retail ---")
    print("Ingrese los precios de los productos. Digite 0 para finalizar la carga.")
    
    while True:
        try:
            precio = float(input("Ingrese precio del producto: $"))

            if precio == 0:
                break
            
            if precio < 0:
                print("El precio no puede ser negativo.")
                continue
                
            total_venta += precio
            
        except ValueError:
            print("Error: Por favor ingrese un número válido.")

    if total_venta < 50000:
        porcentaje = 0.07
        tasa_txt = "7%"
    else:
        porcentaje = 0.12
        tasa_txt = "12%"

    monto_descuento = total_venta * porcentaje
    total_a_pagar = total_venta - monto_descuento

    print("\n--- Resumen de la Venta ---")
    print(f"Sumatoria de precios (sin descuento): ${total_venta:,.0f}")
    print(f"Monto de descuento logrado ({tasa_txt}): ${monto_descuento:,.0f}")
    print(f"Monto final a pagar:                  ${total_a_pagar:,.0f}")

calcular_ventas()
