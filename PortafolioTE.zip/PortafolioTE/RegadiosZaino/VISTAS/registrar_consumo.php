<?php
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}
include "BaseDatos.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $parcela_id = $_POST["parcela_id"];
    $consumo = $_POST["consumo"];
    $sql = "INSERT INTO telemetria (parcela_id, consumo_litros) VALUES ('$parcela_id','$consumo')";
    $conn->query($sql);
}
header("Location: index.php");
?>
