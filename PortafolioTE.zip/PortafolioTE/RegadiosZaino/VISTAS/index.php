<?php
session_start();
if (!isset($_SESSION["usuario"])) {
    header("Location: login.php");
    exit;
}
include "BaseDatos.php";
$usuario = $_SESSION["usuario"];
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="/RegadiosZaino/CSS/style.css">
    <title>Dashboard</title>
</head>
<body>
<div class="container">
    <h2>Bienvenido, <?php echo $usuario["nombre"]; ?></h2>
    <a href="logout.php">Cerrar sesión</a>
    <hr>

    <h3>Consumo de agua</h3>
    <table>
        <tr><th>Parcela</th><th>Fecha</th><th>Consumo (L)</th></tr>
        <?php
        $sql = "SELECT p.nombre AS parcela, t.fecha, t.consumo_litros 
                FROM telemetria t 
                JOIN parcelas p ON t.parcela_id = p.id 
                ORDER BY t.fecha DESC LIMIT 10";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            echo "<tr><td>".$row["parcela"]."</td><td>".$row["fecha"]."</td><td>".$row["consumo_litros"]."</td></tr>";
        }
        ?>
    </table>

    <h3>Registrar nuevo consumo</h3>
    <form method="post" action="registrar_consumo.php">
        <select name="parcela_id" required>
            <?php
            $sql = "SELECT * FROM parcelas";
            $res = $conn->query($sql);
            while ($p = $res->fetch_assoc()) {
                echo "<option value='".$p["id"]."'>".$p["nombre"]."</option>";
            }
            ?>
        </select>
        <input type="number" step="0.01" name="consumo" placeholder="Litros consumidos" required>
        <button type="submit">Registrar</button>
    </form>
</div>
</body>
</html>
