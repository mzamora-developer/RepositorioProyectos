def CalcularEdadFutura(): 
    nombre = input("Inserta tu nombre: ")
    edad = int (input("Ahora inserta tu edad: "))

    EdadMasDecadas = edad + 10

    print("Estimado", nombre, "en una decada su edad será", EdadMasDecadas)

CalcularEdadFutura()



