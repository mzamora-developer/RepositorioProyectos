<?php
require("connect.php"); 

session_start();

if (isset($_SESSION["id_usuario"])) {
    header("location: index.html");
    exit;
}

if (!empty($_POST)) {
    $usuario = mysqli_real_escape_string($mysqli, $_POST["usuario"]);
    $contraseña = mysqli_real_escape_string($mysqli, $_POST["contraseña"]);

    $sha1_pass = sha1($contraseña);

    $sql = "SELECT id FROM usuarios WHERE usuario = '$usuario' AND contraseña = '$sha1_pass'";
    $result = $mysqli->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION["id_usuario"] = $row["id"];
        header("location: index.html");
        exit;
    } else {
        echo "<p style='color:red;'>Nombre de usuario o contraseña incorrectos.</p>";
    }
}
?>

