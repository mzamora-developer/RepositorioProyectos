<?php
include("connect.php"); 
if (!empty($_POST)) {

    
    $usuario = mysqli_real_escape_string($mysqli, $_POST["usuario"]);
    $contraseña = mysqli_real_escape_string($mysqli, $_POST["contraseña"]);

    $sha1_pass = sha1($contraseña);

    if ($usuario == "") {
        echo "Debe escribir un nombre";
    } elseif ($contraseña == "") {
        echo "Debe escribir una contraseña";
    } else {
        $sql = "INSERT INTO usuarios (usuario, contraseña) VALUES ('$usuario', '$sha1_pass')";

        $result = $mysqli->query($sql); 

        if ($result) {
            echo "Usuario registrado";
        } else {
            echo "Error al registrar: " . $mysqli->error;
        }
    }
}
?>
