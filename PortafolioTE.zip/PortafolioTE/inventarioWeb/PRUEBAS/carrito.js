    // Actualizar subtotal y total
    function actualizarTotales() {
        let total = 0;
        $(".producto-carrito").each(function () {
          const precio = parseFloat($(this).data("precio"));
          const cantidad = parseInt($(this).find(".cantidad").val());
          const subtotal = precio * cantidad;
          $(this).find(".subtotal").text(`$${subtotal.toLocaleString()}`);
          total += subtotal;
        });
        $("#total").text(`$${total.toLocaleString()}`);
      }
  
      // Evento para eliminar
      $(".btn-eliminar").click(function () {
        const producto = $(this).closest(".producto-carrito");
        const id_producto = producto.data("id_producto");
  
        $.post("añadir_al_carrito.php", {
          accion: "eliminar",
          id_producto: id_producto
        }, function (respuesta) {
          alert(respuesta);
          producto.remove();
          actualizarTotales();
        });
      });
  
      // Evento para actualizar cantidad
      $(".btn-actualizar").click(function () {
        const producto = $(this).closest(".producto-carrito");
        const id_producto = producto.data("id_producto");
        const cantidad = producto.find(".cantidad").val();
  
        $.post("añadir_al_carrito.php", {
          accion: "añadir",
          id_producto: id_producto,
          cantidad: cantidad
        }, function (respuesta) {
          alert(respuesta);
          actualizarTotales();
        });
      });
  
      // Calcular total inicial
      $(document).ready(function () {
        actualizarTotales();
      });