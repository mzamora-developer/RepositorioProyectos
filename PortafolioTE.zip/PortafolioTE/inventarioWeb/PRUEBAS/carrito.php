<?php
session_start();


$host = "localhost";
$usuario = "root";
$contrasena = "";
$base_datos = "web";

$conn = new mysqli($host, $usuario, $contrasena, $base_datos);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}


$productos_carrito = [];
$total = 0;

if (isset($_SESSION['carrito']) && !empty($_SESSION['carrito'])) {
    $ids = implode(',', array_keys($_SESSION['carrito']));
    $sql = "SELECT * FROM productos WHERE id_producto IN ($ids)";
    $resultado = $conn->query($sql);

    if ($resultado->num_rows > 0) {
        while ($producto = $resultado->fetch_assoc()) {
            $id = $producto['id_producto'];
            $cantidad = $_SESSION['carrito'][$id];
            $subtotal = $producto['precio'] * $cantidad;
            $total += $subtotal;

            $productos_carrito[] = [
                'nombre' => $producto['nombre'],
                'cantidad' => $cantidad,
                'subtotal' => number_format($subtotal, 2)
            ];
        }
    }
}

$conn->close();


include 'carrito_template.php';
?>



insert into carrito where id_producto = id 