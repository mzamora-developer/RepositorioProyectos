document.addEventListener("DOMContentLoaded", function () {
  const contenidoProducto = document.getElementById("contenido-producto");
  const contenidoExpandido = contenidoProducto.querySelector(".contenido-expandido");
  const cerrarBtn = contenidoExpandido.querySelector(".cerrar");


  document.querySelectorAll(".producto button").forEach((boton) => {
    boton.addEventListener("click", (e) => {
      e.stopPropagation();

      const producto = boton.closest(".producto");
      const imagen = producto.querySelector("img");
      const titulo = producto.querySelector("h2");
      const descripcion = producto.querySelector("p");

      document.getElementById("imagen-producto").src = imagen.src;
      document.getElementById("titulo-producto").textContent = titulo.textContent;
      document.getElementById("descripcion-producto").textContent = descripcion.textContent;


      contenidoProducto.setAttribute("data-id-producto", producto.getAttribute("data-id"));

      contenidoProducto.style.display = "flex";
      contenidoProducto.classList.add("mostrar");
    });
  });


  cerrarBtn.addEventListener("click", cerrarContenido);

  function cerrarContenido() {
    contenidoProducto.classList.remove("mostrar");
    setTimeout(() => {
      contenidoProducto.style.display = "none";
    }, 200);
  }


  const btnCarrito = contenidoExpandido.querySelector(".btn-carrito");
  if (btnCarrito) {
    btnCarrito.addEventListener("click", function (e) {
      e.stopPropagation(); 

      const idProducto = contenidoProducto.getAttribute("data-id-producto");
      const cantidad = 1;


      fetch("../php/añadir_al_carrito.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: `id_producto=${idProducto}&cantidad=${cantidad}`,
      })
        .then((response) => response.text())
        .then((data) => {
          console.log("Respuesta del servidor:", data);


          const toast = document.createElement("div");
          toast.className = "toast-carrito";
          toast.textContent = "Producto añadido al carrito";
          document.body.appendChild(toast);

          setTimeout(() => {
            toast.classList.add("show");
          }, 100);

          setTimeout(() => {
            toast.classList.remove("show");
            setTimeout(() => toast.remove(), 300);
            contenidoProducto.style.display = "none";
          }, 2000);
        })
        .catch((error) => {
          console.error("Error al añadir al carrito:", error);
          alert("Error al añadir al carrito.");
        });
    });
  }
});
