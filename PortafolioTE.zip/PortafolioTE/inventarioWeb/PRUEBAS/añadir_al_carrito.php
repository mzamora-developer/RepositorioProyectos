<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id_producto'] ?? null;

    if ($id !== null) {

        if (!isset($_SESSION['carrito'])) {
            $_SESSION['carrito'] = [];
        }


        if (isset($_SESSION['carrito'][$id])) {
            $_SESSION['carrito'][$id]++;
        } else {
            $_SESSION['carrito'][$id] = 1;
        }
    }
}


header('Location: carrito.php');
exit;

