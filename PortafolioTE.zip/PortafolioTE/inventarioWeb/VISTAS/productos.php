<?php

require '../php/data_base.php';
$db = new Database();
$con = $db->conectar();
$sql = $con->prepare("SELECT id, nombre, precio, imagen FROM productos WHERE activo=1");
$sql->execute();
$resultado = $sql->fetchall(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="es">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TIENDA</title>
  <link rel="stylesheet" href="../CSS/productos.css">
  <script src="../JS/productos.js" defer></script>
</head>

<body>

  <header>
    <div class="encabezado">
      <nav>
        <ul class="nav-lista">
          <li><a href="index.html">🏠 Home</a></li>
          <li><a href="productos.html">🎀 Productos</a></li>
          <li><a href="carrito.html">🛒 Carrito</a></li>
          <li><a href=""><img class="gifredondo" src="https://lh4.googleusercontent.com/proxy/JlaSEy7O4OC6S4FCNy9VwVNxegie2ux6sIzWglI6qN7WFIrOJd8ZyPurqAynJ0u0xwJmbEefVR3HXRth2bKD3HpuGSElVw" 
            height="50" width="50" alt="gifcara"></a></li>
        </ul>
      </nav>
    </div>
  </header>

<div class="productos-container">
  <?php foreach($resultado as $row) { $imagen ="../IMG/productos/1/conjunto1.jpg" .$row['imagen'];?>

    <div class="producto">
      <div class="card shadow-sm">
        <img src="../IMG/productos/1/conjunto1.jpg" class="card-img-top">
        <div class="card-body">
          <h5 class="card-title"><?php echo $row['nombre']; ?></h5>
          <p class="card-text">$ <?php echo $row['precio']; ?></p>
          <div class="btn-group">

            <a href="#" class="btn-success">Agregar</a>
          </div>
        </div>
      </div>
    </div>
  <?php } ?>
</div>





  

  <footer>
    <div class="pie-de-pagina">
      <p><a href="">©️ 2025 SitioEjemplo. Todos los derechos reservados. ™</a></p>
    </div>
  </footer>

</body>

</html>
