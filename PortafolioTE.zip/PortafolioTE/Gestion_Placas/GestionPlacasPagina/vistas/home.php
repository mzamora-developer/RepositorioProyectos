<?php
// Inicia o reanuda la sesión del usuario para acceder a $_SESSION
session_start();

// Incluye el archivo que contiene la clase Database para conectarse a MySQL
require_once 'base_datos.php';

// Verifica si existe la variable de sesión 'id_usuario'
// Si no existe, significa que el usuario NO ha iniciado sesión
if (!isset($_SESSION['id_usuario'])) {
    // Redirige al usuario a la página de login
    header('Location: login.php');
    // Detiene la ejecución del script para que no continúe mostrando la página
    exit;
}

// Crea una nueva instancia de la clase Database
$db = new Database();
// Establece la conexión con la base de datos MySQL y guarda el objeto PDO en $conn
$conn = $db->conectar();

// Obtiene el parámetro 'filtro' de la URL (GET)
// Si no existe, usa 'all' como valor por defecto
$filtro = isset($_GET['filtro']) ? $_GET['filtro'] : 'all';

// Verifica si el filtro es 'all' (mostrar todos los productos)
if ($filtro === 'all') {
    // Consulta SQL que une la tabla Productos con EstadoProducto
    // p = alias para Productos, e = alias para EstadoProducto
    $sql = "SELECT p.id_producto, p.nombre, p.descripcion, p.fecha_registro, 
                   e.id_estado, e.tipo_estado 
            FROM Productos p 
            INNER JOIN EstadoProducto e ON p.id_estado = e.id_estado
            ORDER BY p.fecha_registro DESC";
    // Ejecuta la consulta directamente sin parámetros
    $stmt = $conn->query($sql);
} else {
    // Si hay un filtro específico (1 o 2), ejecuta una consulta filtrada
    $sql = "SELECT p.id_producto, p.nombre, p.descripcion, p.fecha_registro, 
                   e.id_estado, e.tipo_estado 
            FROM Productos p 
            INNER JOIN EstadoProducto e ON p.id_estado = e.id_estado
            WHERE p.id_estado = ?
            ORDER BY p.fecha_registro DESC";
    // Prepara la consulta con un placeholder (?) para evitar inyección SQL
    $stmt = $conn->prepare($sql);
    // Ejecuta la consulta reemplazando el ? con el valor de $filtro
    $stmt->execute([$filtro]);
}

// Obtiene todos los resultados de la consulta como un array asociativo
$productos = $stmt->fetchAll();

// Consulta que cuenta el total de productos en la base de datos
$stmt_total = $conn->query("SELECT COUNT(*) as total FROM Productos");
// Obtiene el resultado y extrae el valor 'total'
$total_general = $stmt_total->fetch()['total'];

// Cuenta cuántos productos tienen estado = 1 (Pendientes)
$stmt_pendientes = $conn->query("SELECT COUNT(*) as total FROM Productos WHERE id_estado = 1");
$pendientes_general = $stmt_pendientes->fetch()['total'];

// Cuenta cuántos productos tienen estado = 2 (Entregados)
$stmt_entregados = $conn->query("SELECT COUNT(*) as total FROM Productos WHERE id_estado = 2");
$entregados_general = $stmt_entregados->fetch()['total'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Gestión de Productos - Admin</title>
  <!-- Enlaza el archivo CSS para los estilos de la página -->
  <link rel="stylesheet" href="../css/home.css" />
</head>
<body>
  <main class="wrap">
    <header class="header">
      <div class="header-content">
        <div>
          <h1>Panel Admin — Productos</h1>
          <!-- Muestra el nombre del usuario desde la sesión -->
          <!-- htmlspecialchars() convierte caracteres especiales a HTML para prevenir XSS -->
          <p class="lead">Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?> (<?php echo htmlspecialchars($_SESSION['rol']); ?>)</p>
        </div>
        <!-- Enlace para cerrar sesión -->
        <a href="logout.php" class="btn-logout">Cerrar Sesión</a>
      </div>
      
      <!-- Verifica si existe un mensaje en la URL -->
      <?php if (isset($_GET['mensaje'])): ?>
        <!-- Muestra el mensaje con una clase CSS dinámica según el tipo (success/error) -->
        <div class="alert alert-<?php echo htmlspecialchars($_GET['tipo']); ?>">
          <?php echo htmlspecialchars($_GET['mensaje']); ?>
        </div>
      <?php endif; ?>
    </header>

    <section class="panel">
      <!-- Formulario para crear un nuevo producto -->
      <form method="POST" action="procesar.php" class="form">
        <h2>Registrar producto</h2>
        <!-- Campo oculto que indica a procesar.php qué acción realizar -->
        <input type="hidden" name="accion" value="crear">
        
        <div class="row">
          <label for="nombre">Nombre</label>
          <!-- Campo de texto obligatorio con máximo 100 caracteres -->
          <input id="nombre" name="nombre" type="text" required maxlength="100" placeholder="Nombre del producto" />
        </div>

        <div class="row">
          <label for="descripcion">Descripción</label>
          <!-- Área de texto opcional con máximo 500 caracteres -->
          <textarea id="descripcion" name="descripcion" rows="3" maxlength="500" placeholder="Breve descripción (opcional)"></textarea>
        </div>

        <div class="actions">
          <!-- Botón para enviar el formulario -->
          <button type="submit" class="btn primary">Agregar producto</button>
          <!-- Botón que envía el formulario oculto después de confirmar con JavaScript -->
          <button type="button" onclick="document.getElementById('formEliminarTodos').submit(); return confirm('¿Estás seguro de eliminar TODOS los productos?');" class="btn danger">Borrar todo</button>
        </div>
      </form>

      <!-- Formulario oculto para eliminar todos los productos -->
      <form id="formEliminarTodos" method="POST" action="procesar.php" style="display:none;">
        <input type="hidden" name="accion" value="eliminar_todos">
      </form>

      <!-- Panel lateral con estadísticas -->
      <aside class="summary">
        <div class="stat">
          <!-- Muestra el total de productos -->
          <div class="stat-number"><?php echo $total_general; ?></div>
          <div class="stat-label">Total</div>
        </div>
        <div class="stat">
          <!-- Muestra el total de productos pendientes -->
          <div class="stat-number"><?php echo $pendientes_general; ?></div>
          <div class="stat-label">Pendientes</div>
        </div>
        <div class="stat">
          <!-- Muestra el total de productos entregados -->
          <div class="stat-number"><?php echo $entregados_general; ?></div>
          <div class="stat-label">Entregados</div>
        </div>

        <div class="filter">
          <label>Ver:</label>
          <!-- Formulario GET que recarga la página con el filtro seleccionado -->
          <form method="GET" action="home.php">
            <!-- Select que se auto-envía al cambiar de opción -->
            <select name="filtro" onchange="this.form.submit()">
              <!-- Opción marcada como seleccionada si $filtro === 'all' -->
              <option value="all" <?php echo $filtro === 'all' ? 'selected' : ''; ?>>Todos</option>
              <option value="1" <?php echo $filtro === '1' ? 'selected' : ''; ?>>Pendientes</option>
              <option value="2" <?php echo $filtro === '2' ? 'selected' : ''; ?>>Entregados</option>
            </select>
          </form>
        </div>
      </aside>
    </section>

    <section class="list-section">
      <h2>Lista de productos</h2>
      <div class="products-list">
        <!-- Verifica si el array de productos está vacío -->
        <?php if (empty($productos)): ?>
          <p style="text-align:center; color:#999;">No hay productos registrados</p>
        <?php else: ?>
          <!-- Itera sobre cada producto en el array -->
          <?php foreach ($productos as $producto): ?>
            <!-- Tarjeta del producto con clase CSS dinámica según su estado -->
            <div class="product-card <?php echo $producto['id_estado'] == 1 ? 'pending' : 'delivered'; ?>">
              <div class="product-info">
                <!-- Muestra el nombre del producto escapando caracteres especiales -->
                <h3><?php echo htmlspecialchars($producto['nombre']); ?></h3>
                <!-- Muestra la descripción o 'Sin descripción' si está vacía (operador ternario ?:) -->
                <p><?php echo htmlspecialchars($producto['descripcion'] ?: 'Sin descripción'); ?></p>
                <!-- Formatea y muestra la fecha de registro en formato día/mes/año hora:minuto -->
                <small>Registrado: <?php echo date('d/m/Y H:i', strtotime($producto['fecha_registro'])); ?></small>
              </div>
              <div class="product-actions">
                <!-- Badge que muestra el estado actual con clase CSS dinámica -->
                <span class="status-badge <?php echo $producto['id_estado'] == 1 ? 'pending' : 'delivered'; ?>">
                  <?php echo htmlspecialchars($producto['tipo_estado']); ?>
                </span>
                
                <!-- Formulario inline para cambiar el estado del producto -->
                <form method="POST" action="procesar.php" style="display:inline;">
                  <input type="hidden" name="accion" value="cambiar_estado">
                  <!-- Envía el ID del producto -->
                  <input type="hidden" name="id_producto" value="<?php echo $producto['id_producto']; ?>">
                  <!-- Calcula el nuevo estado: si es 1 lo cambia a 2, si es 2 lo cambia a 1 -->
                  <input type="hidden" name="nuevo_estado" value="<?php echo $producto['id_estado'] == 1 ? 2 : 1; ?>">
                  <!-- Botón con texto dinámico según el estado actual -->
                  <button type="submit" class="btn-toggle">
                    <?php echo $producto['id_estado'] == 1 ? '✓ Marcar entregado' : '↺ Marcar pendiente'; ?>
                  </button>
                </form>
                
                <!-- Formulario inline para eliminar el producto -->
                <form method="POST" action="procesar.php" style="display:inline;">
                  <input type="hidden" name="accion" value="eliminar">
                  <input type="hidden" name="id_producto" value="<?php echo $producto['id_producto']; ?>">
                  <!-- Botón con confirmación JavaScript antes de enviar -->
                  <button type="submit" class="btn-delete" onclick="return confirm('¿Eliminar este producto?')">🗑️</button>
                </form>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </div>
    </section>

    <footer class="footer">
      <small>Gestión de Placas Dentales - Sistema protegido con sesiones PHP</small>
    </footer>
  </main>
</body>
</html>
