<?php
session_start();
require_once 'base_datos.php';

// Verificar autenticación
if (!isset($_SESSION['id_usuario'])) {
    header('Location: index.php');
    exit;
}

$db = new Database();
$conn = $db->conectar();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $accion = $_POST['accion'];
    
    try {
        switch ($accion) {
            case 'crear':
                $nombre = trim($_POST['nombre']);
                $descripcion = trim($_POST['descripcion']);
                
                if (empty($nombre)) {
                    throw new Exception('El nombre es requerido');
                }
                
                $stmt = $conn->prepare("INSERT INTO Productos (nombre, descripcion, id_estado) VALUES (?, ?, 1)");
                $stmt->execute([$nombre, $descripcion]);
                
                header('Location: home.php?mensaje=Producto creado exitosamente&tipo=success');
                break;
                
            case 'cambiar_estado':
                $id_producto = $_POST['id_producto'];
                $nuevo_estado = $_POST['nuevo_estado'];
                
                $stmt = $conn->prepare("UPDATE Productos SET id_estado = ? WHERE id_producto = ?");
                $stmt->execute([$nuevo_estado, $id_producto]);
                
                header('Location: home.php?mensaje=Estado actualizado&tipo=success');
                break;
                
            case 'eliminar':
                $id_producto = $_POST['id_producto'];
                
                $stmt = $conn->prepare("DELETE FROM Productos WHERE id_producto = ?");
                $stmt->execute([$id_producto]);
                
                header('Location: home.php?mensaje=Producto eliminado&tipo=success');
                break;
                
            case 'eliminar_todos':
                $stmt = $conn->prepare("DELETE FROM Productos");
                $stmt->execute();
                
                header('Location: home.php?mensaje=Todos los productos eliminados&tipo=success');
                break;
                
            default:
                throw new Exception('Acción no válida');
        }
        
    } catch (Exception $e) {
        header('Location: home.php?mensaje=' . urlencode($e->getMessage()) . '&tipo=error');
    }
    
    exit;
}

header('Location: home.php');
exit;
?>
