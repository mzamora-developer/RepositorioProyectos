<?php
session_start();

// Si ya está logueado, redirigir al panel
if (isset($_SESSION['id_usuario'])) {
    header('Location: home.php');
    exit;
}

require_once 'base_datos.php';

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($email) || empty($password)) {
        $error = "Por favor completa todos los campos";
    } else {
        try {
            $db = new Database();
            $conn = $db->conectar();
            
            $stmt = $conn->prepare("SELECT id_usuario, nombre, email, password, rol FROM Usuarios WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() > 0) {
                $usuario = $stmt->fetch();
                
                if (password_verify($password, $usuario['password'])) {
                    // Credenciales correctas
                    $_SESSION['id_usuario'] = $usuario['id_usuario'];
                    $_SESSION['nombre'] = $usuario['nombre'];
                    $_SESSION['email'] = $usuario['email'];
                    $_SESSION['rol'] = $usuario['rol'];
                    
                    header('Location: home.php');
                    exit;
                } else {
                    $error = "Contraseña incorrecta";
                }
            } else {
                $error = "Usuario no encontrado";
            }
        } catch (Exception $e) {
            $error = "Error al iniciar sesión: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Gestión de Placas</title>
    <link rel="stylesheet" href="../css/sesiones.css">
</head>
<body>
    <form method="POST" action="login.php">
        <h2>INICIAR SESIÓN</h2>
        
        <?php if (!empty($error)): ?>
            <div class="error-message">❌ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <label>Email: 
            <input type="email" name="email" required>
        </label>
        
        <!-- Campo de contraseña con botón de mostrar/ocultar -->
        <label>Contraseña:
            <div class="password-wrapper">
                <input type="password" name="password" id="password-login" required>
                <button type="button" class="toggle-password" onclick="togglePassword('password-login', this)">
                    👁️
                </button>
            </div>
        </label>
        
        <input type="submit" value="Iniciar Sesión"><br><br>
        
        <a href="registro.php">¿No tienes cuenta? Regístrate aquí ✌️</a>
    </form>

    <script>
        // Función para mostrar/ocultar contraseña
        function togglePassword(inputId, button) {
            const input = document.getElementById(inputId);
            
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈'; // Ojo cerrado
                button.setAttribute('aria-label', 'Ocultar contraseña');
            } else {
                input.type = 'password';
                button.textContent = '👁️'; // Ojo abierto
                button.setAttribute('aria-label', 'Mostrar contraseña');
            }
        }
    </script>
</body>
</html>
