<?php
class Database {
    private $hostname = "localhost";
    private $database = "gestionplacas";
    private $username = "root";
    private $password = "";
    private $charset = "utf8mb4"; // Usar utf8mb4 en lugar de utf8

    public function conectar() {
        try {
            $dsn = "mysql:host=" . $this->hostname . ";dbname=" . $this->database . ";charset=" . $this->charset;
            
            $opciones = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_EMULATE_PREPARES => false, // Desactiva consultas preparadas emuladas
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC // Modo de obtención por defecto
            ];
            
            $pdo = new PDO($dsn, $this->username, $this->password, $opciones);
            return $pdo;
            
        } catch (PDOException $e) {
            // En producción, registra el error en un log en lugar de mostrarlo
            error_log("Error de conexión: " . $e->getMessage());
            throw new Exception("Error al conectar con la base de datos");
        }
    }
}
?>
