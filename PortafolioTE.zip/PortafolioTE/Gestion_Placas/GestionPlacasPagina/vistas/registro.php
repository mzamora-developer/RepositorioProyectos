<?php
session_start();

// Si ya está logueado, redirigir al panel
if (isset($_SESSION['id_usuario'])) {
    header('Location: home.php');
    exit;
}

require_once 'base_datos.php';

$error = '';
$success = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = trim($_POST['nombre']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    if (empty($nombre) || empty($email) || empty($password)) {
        $error = "Por favor completa todos los campos";
    } else {
        try {
            $db = new Database();
            $conn = $db->conectar();
            
            // Verificar si el email ya está registrado
            $stmt = $conn->prepare("SELECT id_usuario FROM Usuarios WHERE email = ?");
            $stmt->execute([$email]);
            
            if ($stmt->rowCount() > 0) {
                $error = "Este email ya está registrado";
            } else {
                // Encriptar contraseña
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                // Insertar nuevo usuario con rol por defecto
                $stmt = $conn->prepare("INSERT INTO Usuarios (nombre, email, password, rol) VALUES (?, ?, ?, 'usuario')");
                $stmt->execute([$nombre, $email, $password_hash]);
                
                $success = "✅ Registro exitoso. Ahora puedes iniciar sesión.";
            }
        } catch (Exception $e) {
            $error = "Error al registrar: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Gestión de Placas</title>
    <link rel="stylesheet" href="../css/sesiones.css">
</head>
<body>
    <form method="POST" action="registro.php">
        <h2>REGISTRO DE USUARIO</h2>
        
        <?php if (!empty($error)): ?>
            <div class="error-message">❌ <?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>
        
        <label>Nombre: 
            <input type="text" name="nombre" required>
        </label>
        
        <label>Email: 
            <input type="email" name="email" required>
        </label>
        
        <!-- Campo de contraseña con botón de mostrar/ocultar -->
        <label>Contraseña:
            <div class="password-wrapper">
                <input type="password" name="password" id="password-registro" required>
                <button type="button" class="toggle-password" onclick="togglePassword('password-registro', this)">
                    👁️
                </button>
            </div>
        </label>
        
        <input type="submit" value="Registrarse"><br><br>
        
        <a href="login.php">¿Ya tienes cuenta? Inicia sesión aquí ✌️</a>
    </form>

    <script>
        // Función para mostrar/ocultar contraseña
        function togglePassword(inputId, button) {
            const input = document.getElementById(inputId);
            
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈'; // Ojo cerrado
                button.setAttribute('aria-label', 'Ocultar contraseña');
            } else {
                input.type = 'password';
                button.textContent = '👁️'; // Ojo abierto
                button.setAttribute('aria-label', 'Mostrar contraseña');
            }
        }
    </script>
</body>
</html>
