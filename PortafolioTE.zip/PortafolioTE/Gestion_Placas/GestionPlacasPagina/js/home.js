/* app.js
   Maneja la lógica en el cliente usando localStorage.
*/
(() => {
  const LS_KEY = "admin_products_v1";

  // Elementos
  const form = document.getElementById("productForm");
  const nameInput = document.getElementById("name");
  const descInput = document.getElementById("desc");
  const productsList = document.getElementById("productsList");
  const totalCount = document.getElementById("totalCount");
  const pendingCount = document.getElementById("pendingCount");
  const deliveredCount = document.getElementById("deliveredCount");
  const filterSelect = document.getElementById("filterSelect");
  const clearAllBtn = document.getElementById("clearAllBtn");

  // Leer/guardar en localStorage
  function readProducts() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error("Error leyendo localStorage", e);
      return [];
    }
  }
  function saveProducts(list) {
    localStorage.setItem(LS_KEY, JSON.stringify(list));
    render();
  }

  // Utils
  function nowISO(){ return new Date().toISOString(); }
  function formatDate(iso){
    if(!iso) return "-";
    const d = new Date(iso);
    return d.toLocaleString();
  }

  // Crear producto
  function addProduct({name, description}){
    const products = readProducts();
    const item = {
      id: Date.now().toString(),
      name: name.trim(),
      description: (description || "").trim(),
      dateAdded: nowISO(),
      dateDelivered: null
    };
    products.unshift(item); // el más reciente arriba
    saveProducts(products);
  }

  // Marcar como entregado (o desmarcar)
  function toggleDelivered(id){
    const products = readProducts();
    const idx = products.findIndex(p => p.id === id);
    if(idx === -1) return;
    products[idx].dateDelivered = products[idx].dateDelivered ? null : nowISO();
    saveProducts(products);
  }

  // Borrar producto
  function deleteProduct(id){
    if(!confirm("¿Eliminar este producto? Esta acción no se puede deshacer.")) return;
    const products = readProducts().filter(p => p.id !== id);
    saveProducts(products);
  }

  // Borrar todo
  function clearAll(){
    if(!confirm("¿Eliminar TODOS los productos? Esta acción no es reversible.")) return;
    localStorage.removeItem(LS_KEY);
    render();
  }

  // Render
  function render(){
    const products = readProducts();
    const filter = filterSelect.value;
    const filtered = products.filter(p => {
      if(filter === "pending") return !p.dateDelivered;
      if(filter === "delivered") return !!p.dateDelivered;
      return true;
    });

    // Estadísticas
    const total = products.length;
    const delivered = products.filter(p => p.dateDelivered).length;
    const pending = total - delivered;
    totalCount.textContent = total;
    pendingCount.textContent = pending;
    deliveredCount.textContent = delivered;

    // Lista
    productsList.innerHTML = "";
    if(filtered.length === 0){
      const div = document.createElement("div");
      div.className = "empty";
      div.textContent = "No hay productos que mostrar.";
      productsList.appendChild(div);
      return;
    }

    filtered.forEach(p => {
      const item = document.createElement("article");
      item.className = "product";
      item.setAttribute("data-id", p.id);

      const main = document.createElement("div");
      main.className = "product-main";

      const titleRow = document.createElement("div");
      titleRow.className = "product-title";

      const title = document.createElement("span");
      title.textContent = p.name;

      const badge = document.createElement("span");
      badge.className = "badge " + (p.dateDelivered ? "delivered" : "pending");
      badge.textContent = p.dateDelivered ? "Entregado" : "Pendiente";

      titleRow.appendChild(title);
      titleRow.appendChild(badge);

      const meta = document.createElement("div");
      meta.className = "meta";
      meta.innerHTML = `Agregado: ${formatDate(p.dateAdded)} ${p.dateDelivered ? `• Entregado: ${formatDate(p.dateDelivered)}` : ""}`;

      const desc = document.createElement("div");
      desc.className = "desc";
      desc.textContent = p.description || "— Sin descripción —";

      main.appendChild(titleRow);
      main.appendChild(meta);
      main.appendChild(desc);

      const actions = document.createElement("div");
      actions.className = "item-actions";

      const toggleBtn = document.createElement("button");
      toggleBtn.className = "icon-btn positive";
      toggleBtn.textContent = p.dateDelivered ? "Marcar pendiente" : "Marcar entregado";
      toggleBtn.title = p.dateDelivered ? "Marcar como pendiente" : "Marcar como entregado";
      toggleBtn.addEventListener("click", () => toggleDelivered(p.id));

      const editBtn = document.createElement("button");
      editBtn.className = "icon-btn warn";
      editBtn.textContent = "Editar";
      editBtn.title = "Editar nombre/descripcion";
      editBtn.addEventListener("click", () => startEdit(p.id));

      const delBtn = document.createElement("button");
      delBtn.className = "icon-btn danger";
      delBtn.textContent = "Eliminar";
      delBtn.title = "Eliminar producto";
      delBtn.addEventListener("click", () => deleteProduct(p.id));

      actions.appendChild(toggleBtn);
      actions.appendChild(editBtn);
      actions.appendChild(delBtn);

      item.appendChild(main);
      item.appendChild(actions);

      productsList.appendChild(item);
    });
  }

  // Edición simple inline: carga en form para editar
  let editingId = null;
  function startEdit(id){
    const products = readProducts();
    const p = products.find(x => x.id === id);
    if(!p) return;
    nameInput.value = p.name;
    descInput.value = p.description || "";
    nameInput.focus();
    editingId = id;
    // Cambiar botón de submit visualmente
    document.querySelector(".btn.primary").textContent = "Guardar cambios";
  }

  function saveEdit(){
    if(!editingId) return;
    const products = readProducts();
    const idx = products.findIndex(p => p.id === editingId);
    if(idx === -1) return;
    products[idx].name = nameInput.value.trim();
    products[idx].description = descInput.value.trim();
    saveProducts(products);
    editingId = null;
    document.querySelector(".btn.primary").textContent = "Agregar producto";
    form.reset();
  }

  // Eventos
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const name = nameInput.value.trim();
    const desc = descInput.value.trim();
    if(!name){
      alert("El nombre del producto es obligatorio.");
      nameInput.focus();
      return;
    }
    if(editingId){
      saveEdit();
      return;
    }
    addProduct({name, description: desc});
    form.reset();
    nameInput.focus();
  });

  filterSelect.addEventListener("change", render);
  clearAllBtn.addEventListener("click", clearAll);

  // inicializar
  render();

})();
